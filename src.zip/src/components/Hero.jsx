import React from 'react'
import HeroIcons from './HeroIcons'
import { useTheme } from '../contexts/ThemeContext'
import { useLanguage } from '../contexts/LanguageContext'
import { FaBootstrap, FaCss3, FaGit, FaHtml5, FaJava, FaLaravel, FaNodeJs, FaPython, FaReact } from 'react-icons/fa'
import { SiExpress, SiGit, SiJavascript, SiMongodb, SiMysql, SiTailwindcss } from 'react-icons/si'

function Hero() {
  const { isDark } = useTheme()
  const { language } = useLanguage()
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      })
    }
  }

  // 🔥 Translations (split into two lines)
  const texts = {
    en: {
      line1: "I'm Oussama",
      line2: "Software Developer Based in Morocco.",
      desc: "I'm a creative developer passionate about building beautiful and functional web.",
      hire: "Hire Me",
    },
    fr: {
      line1: "Je suis Oussama",
      line2: "Développeur logiciel basé au Maroc.",
      desc: "Je suis un développeur créatif, passionné par la création de sites web beaux et fonctionnels.",
      hire: "Embauchez-moi",
    }
  }

  return (
    <main>
      <section className={`min-h-screen flex flex-col justify-center items-center text-center px-4 transition-all duration-500 ${isDark
          ? 'bg-gradient-to-r from-gray-400 via-gray-600 to-black text-white'
          : 'bg-gradient-to-r from-blue-50 to-indigo-100 text-gray-900'
        }`}>

        {/* ✅ Title Split into Two Lines */}
        <div>
          <h1 className="text-4xl md:text-6xl font-bold">
            {texts[language].line1.split("Oussama").map((part, i) => (
              <React.Fragment key={i}>
                {part}
                {i === 0 && <span className="text-gradient-oussama">Oussama</span>}
              </React.Fragment>
            ))}
          </h1>
          <h2 className="text-2xl md:text-4xl font-bold mt-2">
            {texts[language].line2}
          </h2>
        </div>

        {/* ✅ Description */}
        <p className={`mt-4 max-w-2xl transition-colors duration-300 ${isDark ? 'text-gray-300' : 'text-gray-600'
          }`}>
          {texts[language].desc}
        </p>

        {/* ✅ Button + Icons */}
        <div className="mt-6 flex items-center gap-4">
          <button
            onClick={() => scrollToSection('contact')}
            className={`px-6 py-2 rounded-lg font-bold transition-all duration-300 hover:scale-105 ${isDark
                ? 'bg-gradient-to-bl from-blue-500 via-cyan-500 to-gray-600 text-white shadow-[0_0_5px_white]'
                : 'bg-gradient-to-bl from-gray-400 via-gray-600 to-black text-white shadow-[0_0_5px_black]'
              }`}>
            {texts[language].hire}
          </button>
          <HeroIcons />
        </div>
      </section>

      {/* Tech Marquee */}
      <div className='relative'>
        <div className={`absolute top-0 left-0 w-full h-full transform -skew-y-2 origin-top z-0 transition-all duration-500 ${isDark
            ? 'bg-gradient-to-br from-[#e0f3ff] via-[#f0f5ff] to-[#6366f1]'
            : 'bg-gray-700'
          }`}></div>

        <div className={`relative z-10 shadow-lg py-3 overflow-hidden transition-colors duration-500 ${isDark ? 'bg-white dark:bg-black' : 'bg-gradient-to-r from-gray-600 to-black'
          }`}>
          <div className='flex animate-marquee whitespace-nowrap font-semibold text-sm md:text-base gap-8'>
            {/* Tech Stack List */}
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-blue-400'><FaReact /></span>
              <span>React</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-red-400'><FaLaravel /></span>
              <span>Laravel</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-blue-500'><SiTailwindcss /></span>
              <span>Tailwind Css</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-purple-400'><FaBootstrap /></span>
              <span>Bootstrap</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-yellow-400'><FaPython /></span>
              <span>Python</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-orange-400'><FaHtml5 /></span>
              <span>HTML</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-yellow-500'><SiJavascript /></span>
              <span>JavaScript</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-blue-600'><SiMysql /></span>
              <span>MySQL</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-red-600'><FaJava /></span>
              <span>Java</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-green-400'><SiExpress /></span>
              <span>Express.js</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-green-600'><SiMongodb /></span>
              <span>MongoDB</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-red-500'><SiGit /></span>
              <span>Git</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-blue-800'><FaCss3 /></span>
              <span>CSS</span>
            </div>
            <div className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}>
              <span className='text-green-700'><FaNodeJs /></span>
              <span>Node.js</span>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

export default Hero
