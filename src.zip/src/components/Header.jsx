import React from 'react'
import { useTheme } from '../contexts/ThemeContext'
import { useLanguage } from '../contexts/LanguageContext'

function Header() {
  const { isDark, toggleTheme } = useTheme()
  const { language, toggleLanguage } = useLanguage()

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      })
    }
  }

  // Translations
  const texts = {
    en: {
      home: "Home",
      about: "About Me",
      resume: "Resume",
      projects: "Projects",
      services: "Services",
      contact: "Contact Me",
    },
    fr: {
      home: "Accueil",
      about: "À propos",
      resume: "CV",
      projects: "Projets",
      services: "Services",
      contact: "Contactez-moi",
    }
  }

  return (
    <nav className={`fixed top-4 left-1/2 -translate-x-1/2 w-[90%] md:w-[70%] backdrop-blur-lg rounded-full shadow-lg flex justify-between items-center px-6 py-3 transition-all duration-300 z-50 ${isDark
      ? 'bg-[#1b1f2a]/70 text-white'
      : 'bg-white/80 text-gray-900 shadow-xl'
      }`}>
      <span
        className="text-lg font-bold text-gradient-oussama cursor-pointer"
        onClick={() => scrollToSection('hero')}
      >
        LACHHAB OU.
      </span>

      <ul className="hidden md:flex gap-6 text-sm">
        <li onClick={() => scrollToSection('hero')}>{texts[language].home}</li>
        <li onClick={() => scrollToSection('about')}>{texts[language].about}</li>
        <li onClick={() => scrollToSection('resume')}>{texts[language].resume}</li>
        <li onClick={() => scrollToSection('projects')}>{texts[language].projects}</li>
        <li onClick={() => scrollToSection('services')}>{texts[language].services}</li>
        <li>
          <button className="border px-4 py-1 rounded-full" onClick={() => scrollToSection('contact')}>
            {texts[language].contact}
          </button>
        </li>
      </ul>

      <div className="flex gap-3">
        <button
          onClick={toggleLanguage}
          className={`language transition-colors duration-200 ${isDark ? 'text-white' : 'text-gray-900'
            }`}
        >
          🌐 {language === "en" ? "EN" : "FR"}
        </button>

        <button
          onClick={toggleTheme}
          className={`theme p-2 rounded-full transition-all duration-300 hover:scale-110 ${isDark
            ? 'text-yellow-400 hover:bg-yellow-400/10'
            : 'text-orange-500 hover:bg-orange-500/10'
            }`}
        >
          {isDark ? '☀️' : '🌙'}
        </button>
      </div>
    </nav>
  )
}

export default Header
