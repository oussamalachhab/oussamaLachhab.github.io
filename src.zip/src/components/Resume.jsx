import React, { useState } from "react";
import {
    FaEnvelope,
    FaPhone,
    FaMapMarkerAlt,
    FaGithub,
    FaUser,
    FaBook,
    FaBriefcase,
    FaLanguage,
    FaTools,
    FaCertificate,
    FaProjectDiagram
} from "react-icons/fa";
import img from '../assets/me.png'
import { useTheme } from "../contexts/ThemeContext";
import { useLanguage } from "../contexts/LanguageContext";

function Resume() {
    const { isDark } = useTheme();
    const { language } = useLanguage();

    

    return (
        <section className={`min-h-screen flex justify-center py-10 transition-all duration-500 ${isDark
            ? 'bg-gradient-to-r from-gray-400 via-gray-600 to-black text-white'
            : 'bg-gradient-to-r from-blue-50 to-indigo-100 text-gray-900'
            }`}>

            <div className="max-w-6xl flex gap-6">

                {/* ==== LEFT SIDE ==== */}
                <aside className={`w-1/4 rounded-lg p-6 flex flex-col items-center shadow-lg mr-2 transition-all duration-500 ${isDark
                    ? 'bg-gray-700'
                    : 'bg-gray-300'
                    }`}>
                    {/* Profile Photo */}
                    <div className={`w-60 h-70 mb-6 rounded-full overflow-hidden border-8 transition-all duration-500 ${isDark
                        ? 'bg-gradient-to-br from-blue-500 via-cyan-500 to-gray-600 shadow-[0_0_15px_rgba(0,0,0,0.5)] border-white'
                        : 'bg-gradient-to-br from-gray-400 via-gray-600 to-black shadow-[0_0_20px_rgba(59,130,246,0.3)] border-black'
                        }`}>
                        <img src={img} alt="Profile" className="object-cover" />
                    </div>

                    {/* Name */}
                    <h1 className="mt-2 text-2xl font-bold">LACHHAB Oussama</h1>
                    <p className={`text-sm px-3 py-1 rounded mt-2 transition-all duration-500 ${isDark
                        ? 'bg-gray-500'
                        : 'bg-black text-white'
                        }`}>
                        {language === "fr" ? "Ingénierie Logicielle" : "Software Engineering"}
                    </p>

                    {/* Contact Info */}
                    <div className="mt-8 w-full space-y-6 text-sm">
                        {/* Email */}
                        <div>
                            <div className="flex items-center gap-3 text-gray-500 text-xs font-semibold tracking-widest">
                                <FaEnvelope className="text-blue-500 text-base" /> E-MAIL :
                            </div>
                            <p className={`${isDark ? 'text-white' : 'text-black'}`}>lachhab.oussama264@gmail.com</p>
                        </div>
                        <hr className="border-gray-600" />

                        {/* Phone */}
                        <div>
                            <div className="flex items-center gap-3 text-gray-500 text-xs font-semibold tracking-widest">
                                <FaPhone className="text-blue-500 text-base" /> {language === "fr" ? "TÉLÉPHONE :" : "PHONE :"}
                            </div>
                            <p className={`${isDark ? 'text-white' : 'text-black'}`}>+212 6 84 00 12 92</p>
                        </div>
                        <hr className="border-gray-600" />

                        {/* Address */}
                        <div>
                            <div className="flex items-center gap-3 text-gray-500 text-xs font-semibold tracking-widest">
                                <FaMapMarkerAlt className="text-blue-500 text-base" /> {language === "fr" ? "ADRESSE :" : "ADDRESS :"}
                            </div>
                            <p className={`${isDark ? 'text-white' : 'text-black'}`}>Salé, Morocco</p>
                        </div>
                    </div>
                </aside>

                {/* ==== RIGHT SIDE ==== */}
                <main className={`flex-1 rounded-lg p-8 shadow-lg transition-all duration-500 ${isDark ? 'bg-gray-700' : 'bg-gray-300'}`}>
                    {/* Resume Title */}
                    <div className="mb-6">
                        <h1 className={`text-white text-3xl font-bold px-8 py-3 inline-block rounded-tr-3xl rounded-bl-3xl shadow-lg ${isDark
                            ? 'bg-gradient-to-bl from-blue-500 via-cyan-500 to-gray-600'
                            : 'bg-gradient-to-bl from-gray-400 via-gray-600 to-black'
                            }`}>
                            {language === "fr" ? "Curriculum Vitae" : "Resume"}
                        </h1>
                    </div>

                    <div className="flex gap-8">
                        {/* LEFT PART */}
                        <div className="flex-1 space-y-8">
                            {/* About Me */}
                            <section>
                                <h2 className="flex items-center gap-2 text-blue-500 text-xl font-semibold">
                                    <FaUser /> {language === "fr" ? "À propos de moi" : "About Me"}
                                </h2>
                                <p className={`mt-2 text-sm leading-relaxed ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                                    {language === "fr"
                                        ? "Je suis un développeur Full Stack passionné, spécialisé en JavaScript, React.js et Laravel. Pendant mon stage chez Maghreb Arab Press, j’ai acquis une expérience pratique dans la création de plateformes e-commerce et d’applications multi-utilisateurs. En dehors du code, je suis passionné de Formule 1, de voitures et de voyages."
                                        : "I'm a passionate Full Stack Developer with a strong focus on JavaScript, React.js, and Laravel. During my internship at Maghreb Arab Press, I gained hands-on experience building e-commerce platforms and multi-user applications. Beyond coding, I'm an F1 fan, car enthusiast, and traveler."}
                                </p>
                            </section>

                            {/* Experience */}
                            <section>
                                <h2 className="flex items-center gap-2 text-blue-500 text-xl font-semibold">
                                    <FaBriefcase /> {language === "fr" ? "Expérience Professionnelle" : "Professional Experience"}
                                </h2>
                                <p className="mt-2 text-sm">
                                    - <span className="font-semibold">{language === "fr" ? "Développeur Back-end" : "Back-end Developer"}</span>, Maghreb Arab Press (MAP) <br />
                                    <span className={`${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{language === "fr" ? "Avril 2024 - Mai 2024 (Stage)" : "April 2024 - May 2024 (internship)"}</span>
                                </p>
                                <p className="mt-2 text-sm">
                                    - <span className="font-semibold">{language === "fr" ? "Développeur Web Full Stack" : "Full Stack Web Developer"}</span>, Maghreb Arab Press (MAP) <br />
                                    <span className={`${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{language === "fr" ? "Avril 2025 - Juin 2025 (Stage)" : "April 2025 - June 2025 (internship)"}</span>
                                </p>
                            </section>

                            {/* Education */}
                            <section>
                                <h2 className="flex items-center gap-2 text-blue-500 text-xl font-semibold">
                                    <FaBook /> {language === "fr" ? "Formation Académique" : "Academic Background"}
                                </h2>
                                <ul className="mt-2 space-y-2 text-sm">
                                    <li>
                                        <span className="font-semibold"> - {language === "fr" ? "Licence en Ingénierie des Systèmes Informatiques" : "Bachelor in Computer Systems Engineering"}</span> - SUPMTI, Rabat <br />
                                        <span className={`${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{language === "fr" ? "Octobre 2024 - Juillet 2025" : "October 2024 - July 2025"}</span>
                                    </li>
                                    <li>
                                        <span className="font-semibold"> - {language === "fr" ? "Technicien Spécialisé - Développement Full Stack" : "Full Stack Developer - Specialized Technician"}</span> - Rabat <br />
                                        <span className={`${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{language === "fr" ? "Septembre 2022 - Juillet 2024" : "September 2022 - July 2024"}</span>
                                    </li>
                                    <li>
                                        <span className="font-semibold"> - {language === "fr" ? "Baccalauréat en Sciences Physiques" : "High School Diploma in Physical Sciences"}</span> - Salé <br />
                                        <span className={`${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{language === "fr" ? "Juillet 2022" : "July 2022"}</span>
                                    </li>
                                </ul>
                            </section>

                            {/* Projects */}
                            <section>
                                <h2 className="flex items-center gap-2 text-blue-500 text-xl font-semibold">
                                    <FaProjectDiagram /> {language === "fr" ? "Projets" : "Projects"}
                                </h2>
                                <ul className="mt-2 space-y-2 text-sm list-disc list-inside">
                                    <li><b>{language === "fr" ? "E-commerce Chaussures" : "Shoe E-commerce"}:</b> {language === "fr" ? "Plateforme réactive de vente de chaussures" : "Responsive platform for shoe sales"} - React.js</li>
                                    <li><b>{language === "fr" ? "Marketplace Voitures" : "Car Marketplace"}:</b> {language === "fr" ? "Plateforme multi-utilisateurs d'annonces automobiles" : "Multi-user vehicle listings"} - Laravel, MySQL</li>
                                    <li><b>{language === "fr" ? "Bibliothèque de Voitures" : "Car Library"}:</b> {language === "fr" ? "Catalogue automobile" : "Car catalog platform"} - Laravel, React.js, MySQL</li>
                                </ul>
                            </section>
                        </div>

                        {/* RIGHT PART */}
                        <div className="flex-1 space-y-8">
                            {/* Skills */}
                            <section>
                                <h2 className="flex items-center gap-2 text-blue-500 text-xl font-semibold">
                                    <FaTools /> {language === "fr" ? "Compétences" : "Skills"}
                                </h2>
                                <ul className="mt-2 space-y-1 text-sm list-disc list-inside">
                                    <li><b>Languages:</b> JavaScript, Python, HTML, CSS, SQL, C, Java</li>
                                    <li><b>Frameworks:</b> React.js, Express.js, Laravel, Bootstrap, Tailwind</li>
                                    <li><b>Databases:</b> MySQL, MongoDB, SQL Server</li>
                                    <li><b>Tools:</b> Git, GitHub, Linux, WordPress, UML</li>
                                    <li><b>Methodologies:</b> Agile (Scrum, Kanban)</li>
                                    <li><b>Networking:</b> TCP/IP fundamentals</li>
                                </ul>
                            </section>

                            {/* Certificates */}
                            <section>
                                <h2 className="flex items-center gap-2 text-blue-500 text-xl font-semibold">
                                    <FaCertificate /> {language === "fr" ? "Certificats" : "Certificates"}
                                </h2>
                                <ul className="mt-2 space-y-1 text-sm list-disc list-inside">
                                    <li>Front End Development Libraries - FreeCodeCamp</li>
                                    <li>Agile Project Management - HP LIFE</li>
                                    <li>Data Science & Analytics - HP LIFE</li>
                                    <li>Effective Leadership - HP LIFE</li>
                                </ul>
                            </section>

                            {/* Languages */}
                            <section>
                                <h2 className="flex items-center gap-2 text-blue-500 text-xl font-semibold">
                                    <FaLanguage /> {language === "fr" ? "Langues" : "Languages"}
                                </h2>
                                <p className="mt-2 text-sm">
                                    {language === "fr"
                                        ? "Arabe - Natif\nFrançais - Intermédiaire\nAnglais - B1"
                                        : "Arabic - Native\nFrench - Intermediate\nEnglish - B1"}
                                </p>
                            </section>

                            {/* GitHub */}
                            <section>
                                <h2 className="flex items-center gap-2 text-blue-500 text-xl font-semibold">
                                    <FaGithub /> GitHub
                                </h2>
                                <a
                                    href="https://github.com/oussamalachhab"
                                    className={`hover:underline text-base ${isDark ? 'text-white' : 'text-black'}`}
                                >
                                    github.com/oussamalachhab
                                </a>
                            </section>
                        </div>
                    </div>
                </main>
            </div>
        </section>
    );
}

export default Resume;
