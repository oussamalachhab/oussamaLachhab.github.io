// App.js
import React from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import Header from './components/Header';
import Hero from './components/Hero';
import AboutMe from './components/AboutMe';
import MyServices from './components/MyServices';
import Resume from './components/Resume';
import Contact from './components/Contact';
import { LanguageProvider } from './contexts/LanguageContext';
import Projects from './components/Projets';

function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <div className="App">
          <Header />
          <section id="hero">
            <Hero />
          </section>
          <section id="about">
            <AboutMe />
          </section>
          <section id="services">
            <MyServices />
          </section>
          <section id="resume">
            <Resume />
          </section>
          <section id="projects">
            <Projects />
          </section>
          <section id="contact">
            <Contact />
          </section>
        </div>
      </LanguageProvider>

    </ThemeProvider>
  );
}

export default App;