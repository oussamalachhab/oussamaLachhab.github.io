import React from 'react'
import HeroIcons from './HeroIcons'
import { useTheme } from '../contexts/ThemeContext'
import { useLanguage } from '../contexts/LanguageContext'
import { FaBootstrap, FaCss3, FaGit, FaHtml5, FaJava, FaLaravel, FaNodeJs, FaPython, FaReact } from 'react-icons/fa'
import { SiExpress, SiGit, SiJavascript, SiMongodb, SiMysql, SiTailwindcss } from 'react-icons/si'

const TECH_STACK = [
  { name: 'React', icon: <FaReact />, color: 'text-blue-400' },
  { name: 'Laravel', icon: <FaLaravel />, color: 'text-red-400' },
  { name: 'Tailwind Css', icon: <SiTailwindcss />, color: 'text-blue-500' },
  { name: 'Bootstrap', icon: <FaBootstrap />, color: 'text-purple-400' },
  { name: 'Python', icon: <FaPython />, color: 'text-yellow-400' },
  { name: 'HTML', icon: <FaHtml5 />, color: 'text-orange-400' },
  { name: 'JavaScript', icon: <SiJavascript />, color: 'text-yellow-500' },
  { name: 'MySQL', icon: <SiMysql />, color: 'text-blue-600' },
  { name: 'Java', icon: <FaJava />, color: 'text-red-600' },
  { name: 'Express.js', icon: <SiExpress />, color: 'text-green-400' },
  { name: 'MongoDB', icon: <SiMongodb />, color: 'text-green-600' },
  { name: 'Git', icon: <SiGit />, color: 'text-red-500' },
  { name: 'CSS', icon: <FaCss3 />, color: 'text-blue-800' },
  { name: 'Node.js', icon: <FaNodeJs />, color: 'text-green-700' },
]

function Hero() {
  const { isDark } = useTheme()
  const { language } = useLanguage()
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      })
    }
  }

  // 🔥 Translations (split into two lines)
  const texts = {
    en: {
      line1: "I'm Oussama ",
      line2: "Software Developer Based in Morocco.",
      desc: "I'm a creative developer passionate about building beautiful and functional web.",
      hire: "Hire Me",
    },
    fr: {
      line1: "Je suis Oussama",
      line2: "Développeur logiciel basé au Maroc.",
      desc: "Je suis un développeur créatif, passionné par la création de sites web beaux et fonctionnels.",
      hire: "Embauchez-moi",
    }
  }

  return (
    <main>
      <section className={`min-h-screen flex flex-col justify-center items-center text-center px-4 transition-all duration-500 ${isDark
          ? 'bg-gradient-to-r from-gray-400 via-gray-600 to-black text-white'
          : 'bg-gradient-to-r from-blue-50 to-indigo-100 text-gray-900'
        }`}>

        {/* ✅ Title Split into Two Lines */}
        <div>
          <h1 className="text-4xl md:text-6xl font-bold">
            {texts[language].line1.split("Oussama").map((part, i) => (
              <React.Fragment key={i}>
                {part}
                {i === 0 && <span className="text-gradient-oussama">Oussama</span>}
              </React.Fragment>
            ))}
          </h1>
          <h2 className="text-2xl md:text-4xl font-bold mt-2">
            {texts[language].line2}
          </h2>
        </div>

        {/* ✅ Description */}
        <p className={`mt-4 max-w-2xl transition-colors duration-300 ${isDark ? 'text-gray-300' : 'text-gray-600'
          }`}>
          {texts[language].desc}
        </p>

        {/* ✅ Button + Icons */}
        <div className="mt-6 flex items-center gap-4">
          <button
            onClick={() => scrollToSection('contact')}
            className={`px-6 py-2 rounded-lg font-bold transition-all duration-300 hover:scale-105 ${isDark
                ? 'bg-gradient-to-bl from-blue-500 via-cyan-500 to-gray-600 text-white shadow-[0_0_5px_white]'
                : 'bg-gradient-to-bl from-gray-400 via-gray-600 to-black text-white shadow-[0_0_5px_black]'
              }`}>
            {texts[language].hire}
          </button>
          <HeroIcons />
        </div>
      </section>

      {/* Tech Marquee */}
      <div className='relative'>
        <div className={`absolute top-0 left-0 w-full h-full transform -skew-y-2 origin-top z-0 transition-all duration-500 ${isDark
            ? 'bg-gradient-to-br from-[#e0f3ff] via-[#f0f5ff] to-[#6366f1]'
            : 'bg-gray-700'
          }`}></div>

        <div className={`relative z-10 shadow-lg py-3 overflow-hidden transition-colors duration-500 ${isDark ? 'bg-white dark:bg-black' : 'bg-gradient-to-r from-gray-600 to-black'
          }`}>
          <div className='flex w-max animate-marquee whitespace-nowrap font-semibold text-sm md:text-base'>
            {/* La liste est dupliquée deux fois pour que la boucle soit continue, sans trou visible */}
            {[0, 1].map((copy) => (
              <div key={copy} className='flex gap-8' aria-hidden={copy === 1}>
                {TECH_STACK.map((tech) => (
                  <div
                    key={tech.name}
                    className={`flex items-center gap-2 px-10 ${isDark ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300'}`}
                  >
                    <span className={tech.color}>{tech.icon}</span>
                    <span>{tech.name}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}

export default Hero
