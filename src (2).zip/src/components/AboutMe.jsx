import React from 'react'
import { FaLaravel, FaReact } from 'react-icons/fa'
import { useTheme } from '../contexts/ThemeContext'
import { useLanguage } from '../contexts/LanguageContext'
import img from '../assets/me.png'
import cv from '../assets/CV.pdf'
import { SiJavascript, SiMysql } from 'react-icons/si'

function AboutMe() {
    const { isDark } = useTheme();
    const { language } = useLanguage();

    // === TRANSLATIONS ===
    const translations = {
        en: {
            subtitle: "About me",
            title: "Who Am I",
            description: [
                "I'm LACHHAB Oussama, a passionate Full Stack Developer specializing in JavaScript, React.js, and Laravel. I've built e-commerce platforms and multi-user applications during my internship at Maghreb Arab Press, gaining hands-on experience in both front-end and back-end development.",
                "When I'm not coding, you'll find me following Formula 1, exploring new destinations, or geeking out over cars. I'm driven by curiosity, creativity, and the challenge of building impactful digital experiences."
            ],
            download: "Download CV",
            react: "ReactJs",
            js: "JavaScript",
            laravel: "Laravel",
            mysql: "MySQL",
            photoAlt: "Photo of LACHHAB Oussama",
        },
        fr: {
            subtitle: "À propos de moi",
            title: "Qui suis-je",
            description: [
                "Je suis LACHHAB Oussama, un développeur Full Stack passionné spécialisé en JavaScript, React.js et Laravel. J'ai construit des plateformes e-commerce et des applications multi-utilisateurs lors de mon stage à Maghreb Arab Press, acquérant une solide expérience pratique en développement front-end et back-end.",
                "En dehors du code, je suis passionné de Formule 1, d'exploration de nouvelles destinations et d'automobiles. Ma curiosité et ma créativité me poussent à créer des expériences numériques impactantes."
            ],
            download: "Télécharger le CV",
            react: "ReactJs",
            js: "JavaScript",
            laravel: "Laravel",
            mysql: "MySQL",
            photoAlt: "Photo de LACHHAB Oussama",
        }
    };

    const t = translations[language];

    return (
        <section className={`py-16 px-8 flex flex-col md:flex-row items-center gap-12 min-h-screen justify-center transition-all duration-500 ${
            isDark 
                ? 'bg-gradient-to-r from-gray-400 via-gray-600 to-black text-white' 
                : 'bg-gradient-to-r from-gray-50 to-blue-50 text-gray-900'
        }`}>
            {/* Image Section */}
            <div className={`w-full md:w-1/2 max-w-md border-4 rounded-lg flex items-center justify-center p-4 transition-all duration-300 ${
                isDark 
                    ? 'bg-gradient-to-br from-blue-500 via-cyan-500 to-gray-600 shadow-[0_0_15px_rgba(0,0,0,0.5)] border-white' 
                    : 'bg-gradient-to-br from-gray-400 via-gray-600 to-black shadow-[0_0_20px_rgba(59,130,246,0.3)] border-black'
            }`}>
                <img
                    src={img}
                    alt={t.photoAlt}
                    loading="lazy"
                    className="w-full h-auto object-cover rounded-md"
                />
            </div>

            {/* Content Section */}
            <div className="md:w-1/2">
                <p className={`font-semibold mb-2 transition-colors duration-300 ${
                    isDark ? 'text-blue-400' : 'text-blue-600'
                }`}>
                    {t.subtitle}
                </p>
                
                <h2 className={`text-4xl font-bold mb-4 transition-colors duration-300 ${
                    isDark ? 'text-white' : 'text-gray-900'
                }`}>
                    {t.title}
                </h2>
                
                {t.description.map((paragraph, i) => (
                    <p
                        key={i}
                        className={`mb-4 last:mb-6 leading-relaxed transition-colors duration-300 ${
                            isDark ? 'text-gray-300' : 'text-gray-600'
                        }`}
                    >
                        {paragraph}
                    </p>
                ))}

                {/* Tech Stack Pills */}
                <div className="flex flex-wrap gap-4 mb-6">
                    <div className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 ${
                        isDark 
                            ? 'bg-[#111] text-white border border-gray-700' 
                            : 'bg-white text-gray-800 border border-gray-200 shadow-md'
                    }`}>
                        <FaReact className="text-blue-500" /> {t.react}
                    </div>
                    
                    <div className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 ${
                        isDark 
                            ? 'bg-[#111] text-white border border-gray-700' 
                            : 'bg-white text-gray-800 border border-gray-200 shadow-md'
                    }`}>
                        <SiJavascript className="text-yellow-500" /> {t.js}
                    </div>
                    
                    <div className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 ${
                        isDark 
                            ? 'bg-[#111] text-white border border-gray-700' 
                            : 'bg-white text-gray-800 border border-gray-200 shadow-md'
                    }`}>
                        <FaLaravel className="text-red-400" /> {t.laravel}
                    </div>
                    
                    <div className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 ${
                        isDark 
                            ? 'bg-[#111] text-white border border-gray-700' 
                            : 'bg-white text-gray-800 border border-gray-200 shadow-md'
                    }`}>
                        <SiMysql className="text-blue-600" /> {t.mysql}
                    </div>
                </div>

                {/* Download CV Button */}
                <a
                    href={cv}
                    className={`inline-block px-6 py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 hover:shadow-lg ${
                        isDark 
                            ? 'bg-gradient-to-bl from-blue-500 via-cyan-500 to-gray-600 shadow-[0_0_5px_white]' 
                            : 'bg-gradient-to-bl from-gray-400 via-gray-600 to-black text-white shadow-[0_0_5px_black]'
                    }`}
                    download
                >
                    {t.download}
                </a>
            </div>
        </section>
    )
}

export default AboutMe
